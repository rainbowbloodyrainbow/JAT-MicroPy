import time
import machine

# 伺服电机：ESP32用D2（替代Pico GPIO15），PWM模式（频率50Hz，与原代码一致）
servo_pwm = machine.PWM(machine.Pin(2))
servo_pwm.freq(50)

open_button = machine.Pin(26, machine.Pin.IN, machine.Pin.PULL_DOWN)
close_button = machine.Pin(25, machine.Pin.IN, machine.Pin.PULL_DOWN)

# 状态指示灯 (GP18, GP19)
green_led = machine.Pin(18, machine.Pin.OUT) # 开启指示灯
red_led = machine.Pin(19, machine.Pin.OUT)   # 关闭指示灯

# ----- 核心函数：伺服电机角度控制-----
# PWM脉冲宽度映射
def set_servo_angle(angle):
    if 0 <= angle <= 180:
        # 映射角度到脉冲宽度（500k-2.5M纳秒，适配舵机标准）
        duty_ns = int(500000 + (angle / 180) * 2000000)
        servo_pwm.duty_ns(duty_ns)

#print("初始化道闸位置：关闭 (0度)")
#set_servo_angle(0)
#time.sleep(1) # 等待1秒，确保电机到位
# 状态变量：True表示道闸已开启, False表示道闸已关闭
# 程序启动时，默认道闸是关闭的
barrier_is_open = False 
print("停车场道闸系统已启动，当前状态：关闭")

# 初始状态设置
set_servo_angle(90)
red_led.on()
green_led.off()


while True:
    if open_button.value() == 1 and not barrier_is_open:
        print("收到开启指令...")
        barrier_is_open = True  # 1. 更新状态
        set_servo_angle(0)     # 2. 执行动作
        green_led.on()          # 3. 更新指示灯
        red_led.off()
        print("道闸已开启")
        
    # 检查“关闭”按钮是否被按下
    if close_button.value() == 1 and barrier_is_open:
        print("收到关闭指令...")
        barrier_is_open = False # 1. 更新状态
        set_servo_angle(90)      # 2. 执行动作
        red_led.on()            # 3. 更新指示灯
        green_led.off()
        print("道闸已关闭")

    # 短暂延时，防止CPU占用过高，也起到简单的防抖作用
    time.sleep(0.05)
   
   





