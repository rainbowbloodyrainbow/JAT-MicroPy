import machine
import time

# ----- 1. 硬件引脚初始化（适配ESP32，修正列引脚笔误）-----
KEYS = [['1','2','3','A'], ['4','5','6','B'], ['7','8','9','C'], ['*','0','#','D']]
rows = [
    machine.Pin(23, machine.Pin.OUT),  # 行1→D23
    machine.Pin(22, machine.Pin.OUT),  # 行2→D22
    machine.Pin(21, machine.Pin.OUT),  # 行3→D21
    machine.Pin(19, machine.Pin.OUT)   # 行4→D19
]
cols = [
    machine.Pin(27, machine.Pin.IN, machine.Pin.PULL_UP),   # 列1→D27
    machine.Pin(26, machine.Pin.IN, machine.Pin.PULL_UP),   # 列2→D26
    machine.Pin(25, machine.Pin.IN, machine.Pin.PULL_UP),   # 列3→D25
    machine.Pin(14, machine.Pin.IN, machine.Pin.PULL_UP)    # 列4→D14
]

# 伺服电机（D5，PWM频率50Hz）
servo = machine.PWM(machine.Pin(5))
servo.freq(50)

# LED指示灯（绿→D2，红→D15）
green_led = machine.Pin(2, machine.Pin.OUT)
red_led = machine.Pin(15, machine.Pin.OUT)

# ----- 2. 核心配置与函数（适配ESP32电平控制）-----
CORRECT_PASSWORD = ['1', '2', '3', '4']
input_buffer = []

def set_servo_angle(angle):
    duty_ns = int(500000 + (angle / 180) * 2000000)
    servo.duty_ns(duty_ns)

def scan_keypad():
    """适配ESP32：用value(0)/value(1)替代low()/high()"""
    for r, row_pin in enumerate(rows):
        row_pin.value(0)  # 置低行引脚（替代row_pin.low()）
        for c, col_pin in enumerate(cols):
            if col_pin.value() == 0:
                time.sleep(0.1)
                while col_pin.value() == 0:
                    pass
                row_pin.value(1)  # 置高行引脚（替代row_pin.high()）
                return KEYS[r][c]
        row_pin.value(1)  # 置高行引脚（替代row_pin.high()）
    return None

def reset_system():
    global input_buffer
    print("\n系统已重置，请输入密码...")
    input_buffer = []
    set_servo_angle(0)
    green_led.off()
    red_led.off()

# ----- 3. 主循环 -----
reset_system()

while True:
    key = scan_keypad()
    if key:
        print(f"输入: {key}")
        if key == '#':
            if input_buffer == CORRECT_PASSWORD:
                print("密码正确！门已打开。")
                green_led.on()
                set_servo_angle(90)
                time.sleep(5)
                reset_system()
            else:
                print("密码错误！")
                red_led.on()
                time.sleep(2)
                reset_system()
        elif key == '*':
            print("输入已清空。")
            reset_system()
        else:
            input_buffer.append(key)
            print(f"当前输入: {''.join(input_buffer)}")