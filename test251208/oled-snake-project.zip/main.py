from machine import Pin, I2C
from ssd1306 import SSD1306_I2C
from utime import sleep_ms
from random import randint

# ESP32 Pin assignment 
i2c = I2C(0, scl=Pin(22), sda=Pin(21))

up_btn   =Pin(2,Pin.IN,Pin.PULL_UP)
down_btn =Pin(5, Pin.IN,Pin.PULL_UP)
left_btn =Pin(15, Pin.IN,Pin.PULL_UP)
right_btn=Pin(4, Pin.IN,Pin.PULL_UP)


SCREEN_WIDTH        =128 # OLED display width, in pixels
SCREEN_HEIGHT       =64  # OLED display height, in pixels

SNAKE_PIECE_SIZE     =3
MAX_SANKE_LENGTH     =165
MAP_SIZE_X           =20
MAP_SIZE_Y           =20
STARTING_SNAKE_SIZE  =5
SNAKE_MOVE_DELAY     =30

SSD1306_INVERSE      =0
SSD1306_WHITE        =1

START               =0
RUNNING             =1
GAMEOVER            =2



LEFT                =0
UP                  =1
RIGHT               =2
DOWN                =3

display = SSD1306_I2C(SCREEN_WIDTH ,SCREEN_HEIGHT , i2c)
snake =[[0]*2 for _ in range(MAX_SANKE_LENGTH)] 

fruit = [0]*2

snake_length = 5

gameState = START
newDir = RIGHT

def resetSnake():
    snake_length = STARTING_SNAKE_SIZE
    for i in range(snake_length):
        snake[i][0] = MAP_SIZE_X // 2 - i
        snake[i][1] = MAP_SIZE_Y // 2

def generateFruit():
    fruit[0] = randint(1, MAP_SIZE_X-1)
    fruit[1] = randint(1, MAP_SIZE_Y-1)
    for i in range(snake_length):
        if fruit[0] == snake[i][0] and fruit[1] == snake[i][1]:
            generateFruit()
        else:
            break
def checkFruit():
    global snake_length
    if fruit[0] == snake[0][0] and fruit[1] == snake[0][1]:
        if snake_length <= MAX_SANKE_LENGTH-1:
            snake_length += 1
        generateFruit()
 
def buttonPress():
    global newDir
    if up_btn.value()==0:
        newDir = UP
        return True
    elif down_btn.value()==0:
        newDir = DOWN
        return True
    elif left_btn.value()==0:
        newDir = LEFT
        return True
    elif right_btn.value()==0:
        newDir = RIGHT
        return True
    return False

def drawMap():
    offsetMapX = SCREEN_WIDTH - SNAKE_PIECE_SIZE * MAP_SIZE_X - 2
    offsetMapY = 2

    display.rect(fruit[0] * SNAKE_PIECE_SIZE + offsetMapX, fruit[1] * SNAKE_PIECE_SIZE + offsetMapY, SNAKE_PIECE_SIZE, SNAKE_PIECE_SIZE, SSD1306_WHITE)
    display.rect(offsetMapX - 2, 0, SNAKE_PIECE_SIZE * MAP_SIZE_X + 4, SNAKE_PIECE_SIZE * MAP_SIZE_Y + 4, SSD1306_WHITE)
    for i in range(snake_length):
        display.fill_rect(snake[i][0] * SNAKE_PIECE_SIZE + offsetMapX, snake[i][1] * SNAKE_PIECE_SIZE + offsetMapY, SNAKE_PIECE_SIZE, SNAKE_PIECE_SIZE, SSD1306_WHITE) 

def drawScore():
    display.text('Score:', 0, 0)    
    display.text(str(snake_length - STARTING_SNAKE_SIZE), 10, 12)    

def drawPressToStart():
    display.text("Press a",0,25)
    display.text("button",0,35)
    display.text("to",0,45)
    display.text("start! ",0,55)

def drawGameover():
    display.text("GAME",0,45)
    display.text(" OVER! ",0,55)


def setupGame():
    global snake_length
    snake_length = 5
    gameState = START
    newDir = RIGHT
    resetSnake()
    generateFruit()
    display.fill(0)
    drawMap()
    drawScore()
    drawPressToStart()
    display.show()

def collisionCheck(x,y): 
    for i in range(1,snake_length):
        if x == snake[i][0] and y == snake[i][1]:
            return True
    if x < 0 or y < 0 or x >= MAP_SIZE_X or y >= MAP_SIZE_Y:
        return True
    return False

def moveSnake(direction):
    x = snake[0][0]
    y = snake[0][1]

    if direction==LEFT:
        x -= 1
    elif direction==UP:
        y -= 1
    elif direction==RIGHT:
        x += 1
    elif direction==DOWN:
        y += 1
    
    if collisionCheck(x, y):
        return True

    for i in range(snake_length - 1,0,-1):
        snake[i][0] = snake[i - 1][0]
        snake[i][1] = snake[i - 1][1]

    snake[0][0] = x
    snake[0][1] = y
    return False

moveTime = 0
setupGame()

while True:
    if gameState==START:
        if buttonPress():
            gameState = RUNNING
    elif gameState==RUNNING:
        moveTime+=1
        buttonPress()
        if moveTime >= SNAKE_MOVE_DELAY:
            display.fill(0)
            if moveSnake(newDir):
                gameState = GAMEOVER
                drawGameover()
                sleep_ms(1000)
            drawMap()
            drawScore()
            display.show()
            checkFruit()
            moveTime = 0
    elif  gameState==GAMEOVER:
        if buttonPress():
            setupGame()
            gameState = START
    sleep_ms(5)